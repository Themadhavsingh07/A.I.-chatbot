# Init voice module
