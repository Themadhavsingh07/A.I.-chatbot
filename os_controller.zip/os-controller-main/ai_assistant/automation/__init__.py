# Init automation module
