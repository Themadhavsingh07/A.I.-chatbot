# Init ai module
